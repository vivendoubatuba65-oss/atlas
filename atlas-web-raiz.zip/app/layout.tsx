import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Atlas ERP',
  description: 'O gerente virtual do seu negócio.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="bg-paper text-ink font-body antialiased">{children}</body>
    </html>
  );
}
