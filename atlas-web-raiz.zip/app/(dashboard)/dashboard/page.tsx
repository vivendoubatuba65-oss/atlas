import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

export default async function DashboardPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  // RLS garante que só vem o perfil (e a empresa) do próprio usuário.
  const { data: profile } = await supabase
    .from('profiles')
    .select('nome, empresa_id, empresas(nome)')
    .eq('id', user!.id)
    .single();

  // RLS garante que só vêm produtos da empresa do usuário logado.
  const { data: produtosEstoqueBaixo } = await supabase
    .from('produtos')
    .select('id, nome, estoque_atual, estoque_minimo')
    .lte('estoque_atual', 'estoque_minimo' as unknown as number)
    .limit(5);

  return (
    <main className="min-h-screen p-8">
      <h1 className="font-display text-2xl font-semibold">
        Olá, {profile?.nome ?? 'usuário'}
      </h1>
      <p className="mb-8 text-ink/60">
        {(profile as { empresas?: { nome?: string } } | null)?.empresas?.nome}
      </p>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card label="Receita do dia" value="R$ 0,00" />
        <Card label="Lucro" value="R$ 0,00" />
        <Card label="Caixa" value="R$ 0,00" />
        <Card label="Meta do dia" value="0%" />
      </div>

      <section className="mt-8">
        <h2 className="mb-3 font-display text-lg font-semibold">
          Estoque baixo
        </h2>
        {produtosEstoqueBaixo && produtosEstoqueBaixo.length > 0 ? (
          <ul className="divide-y divide-ink/10 rounded-lg border border-ink/10 bg-white">
            {produtosEstoqueBaixo.map((p) => (
              <li key={p.id} className="flex justify-between px-4 py-3 text-sm">
                <span>{p.nome}</span>
                <span className="text-alert">
                  {p.estoque_atual} / mín. {p.estoque_minimo}
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-ink/50">Nenhum produto com estoque baixo.</p>
        )}
      </section>
    </main>
  );
}

function Card({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-ink/10 bg-white p-4">
      <p className="text-sm text-ink/60">{label}</p>
      <p className="font-display text-2xl font-semibold">{value}</p>
    </div>
  );
}
