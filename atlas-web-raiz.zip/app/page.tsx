import Link from 'next/link';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 p-8 text-center">
      <h1 className="font-display text-4xl font-semibold">Atlas ERP</h1>
      <p className="max-w-md text-ink/70">
        O gerente virtual do seu negócio. Financeiro, estoque, PDV e clientes
        em um só lugar — pronto em cinco minutos.
      </p>
      <Link
        href="/login"
        className="rounded-md bg-accent px-6 py-3 font-medium text-paper transition hover:opacity-90"
      >
        Entrar
      </Link>
    </main>
  );
}
